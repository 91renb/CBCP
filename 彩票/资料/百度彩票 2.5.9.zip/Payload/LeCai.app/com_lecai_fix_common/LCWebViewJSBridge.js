;(function() {
    if (window.LCAppWebJSBridge) { return }

    var messagingIframe
    var sendMessageQueue = []
  
    var CUSTOM_PROTOCOL_SCHEME = 'lcwvjbscheme'
    var QUEUE_HAS_MESSAGE = '__WVJB_QUEUE_MESSAGE__'
  
    function _createQueueReadyIframe(doc) {
		messagingIframe = doc.createElement('iframe')
		messagingIframe.style.display = 'none'
        messagingIframe.src = CUSTOM_PROTOCOL_SCHEME + '://' + QUEUE_HAS_MESSAGE
		doc.documentElement.appendChild(messagingIframe)
    }
  
    function _refreshIframe() {
        var messagingIframe = document.getElementById('lciframeios')
        if(messagingIframe) {
            document.documentElement.removeChild(messagingIframe)
        }
  
        messagingIframe = document.createElement('iframe')
		messagingIframe.style.display = 'none'
        messagingIframe.id = 'lciframeios'
        messagingIframe.src = CUSTOM_PROTOCOL_SCHEME + '://' + QUEUE_HAS_MESSAGE
		document.documentElement.appendChild(messagingIframe)
    }
  
    function send(data) {
		sendMessageQueue.push(data)
        _refreshIframe()
    }
  
    function _fetchQueue() {
        var messageQueueString = JSON.stringify(sendMessageQueue)
        sendMessageQueue = []
        return messageQueueString
    }
  
    window.LCAppWebJSBridge = {
		send: send,
		_fetchQueue: _fetchQueue
    }
  
    var doc = document
    var readyEvent = doc.createEvent('Events')
    readyEvent.initEvent('LCAppWebJSBridgeReady')
    readyEvent.bridge = LCAppWebJSBridge
    doc.dispatchEvent(readyEvent)
})();
