
;(function() {
  
  if (window.NEPJSBridge) {return}
  
  var messageIframe
  var messageHandlers = {}
  var responseCallbacks = {}
  var sendMessageQueue = []
  var NEP_PROTOCOL_SCHEME = 'epaysdk'
  var NEP_HAS_MESSAGE = '__NEPJSBridge_HAS_MESSAGE__'
  
  var uniqueId = 0
  
  function createQueueReadyIframe(doc) {
		messageIframe = doc.createElement('iframe')
		messageIframe.style.display = 'none'
		messageIframe.src = NEP_PROTOCOL_SCHEME + '://' + NEP_HAS_MESSAGE
		doc.documentElement.appendChild(messageIframe)
  }
  
  function registerDefaultHandler(messageHandler) {
		if (NEPJSBridge.messageHandler) {throw new Error('NEPJSBridge.init called twice')}
  
		NEPJSBridge.messageHandler = messageHandler
  }
  
  function registerHandler(handlerName, handler) {
		messageHandlers[handlerName] = handler
  }
  
  function sendData(message,responseCallback) {
		_sendData({message:message}, responseCallback)
  }
  
  function _sendData(message, responseCallback) {
		if (responseCallback) {
  var callbackId = 'callbackId_'+(uniqueId++)+'_'+new Date().getTime()
  responseCallbacks[callbackId] = responseCallback
  message['callbackId'] = callbackId
		}
		sendMessageQueue.push(message);
  
		messageIframe.src = NEP_PROTOCOL_SCHEME + '://' + NEP_HAS_MESSAGE
  }
  
  function fetchQueue() {
		var messageQueueString = JSON.stringify(sendMessageQueue)
		sendMessageQueue = []
		return messageQueueString
  }
  
  function handleMessageFromNative(messageJSON) {
		setTimeout(function _timeoutHandleMessageFromNative() {
                   var message = JSON.parse(messageJSON)
                   var messageHandler
                   var responseCallback
                   if (message.responseId) {
                   responseCallback = responseCallbacks[message.responseId]
                   if (!responseCallback) {return;}
                   responseCallback(message.message)
                   delete responseCallbacks[message.responseId]
                   }
                   else {
                   if (message.callbackId) {
                   var callbackResponseId = message.callbackId
                   responseCallback = function(responseData) {
                   _sendData({responseId : callbackResponseId, message:responseData})
                   }
                   }
                   
                   var handler = NEPJSBridge.messageHandler
                   
                   if (message.handlerName) {
                   handler = messageHandlers[message.handlerName]
                   }
                   
                   try {
                   handler(message.message, responseCallback)
                   } catch(exception) {
                   if (typeof console != 'undefined') {
                   console.log("NEPJSBridge: WARNING: javascript handler threw.", message, exception)
                   }
                   }
                   }
                   
                   })
  }
  
  window.NEPJSBridge = {
		registerDefaultHandler:registerDefaultHandler,
		sendData:sendData,
		registerHandler:registerHandler,
		fetchQueue:fetchQueue,
		handleMessageFromNative:handleMessageFromNative
  }
  
  var doc = document
  createQueueReadyIframe(doc)
  var readyEvent = doc.createEvent('Events')
  readyEvent.initEvent('NEPJSBridgeReady')
  readyEvent.bridge = NEPJSBridge
  doc.dispatchEvent(readyEvent)
  
  })();